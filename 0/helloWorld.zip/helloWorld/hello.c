#include <stdio.h>

int main()
{
	printf("Heloo, world!\n");
	return 0; 
}
