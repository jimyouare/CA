#include <stdio.h>

/* A simple "Hello, world!"*/
int main(int argc, char **argv)
{
  printf("Hello, world!\n");
  return 0;
}

