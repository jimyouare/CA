#include <stdio.h>

int main(){

   char var2[30];

   printf("Address of var2 variable: %u\n", (unsigned int)&var2);
   printf("Address of var2[29] variable: %u\n", (unsigned int)&var2[29]);

   return 0;
}