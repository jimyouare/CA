#include <stdio.h>

int main () {
   int  var = 20;   // actual variable declaration.
   int  *ip;        // pointer variable 

   ip = &var;       // store address of var in pointer variable

   printf("Value of var variable: %d\n", var);
   
   // print the address stored in ip pointer variable
   printf("Address stored in ip variable: %u\n", (unsigned int)ip);


   // access the value at the address available in pointer
   printf("Value of *ip variable: %d\n", *ip);

   return 0;
}