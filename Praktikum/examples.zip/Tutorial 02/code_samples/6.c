#include <stdio.h>
 
int main () {

   int a = 10;

   while( a <= 20 ) {
   
      printf("value of a: %d\n", a);
      a+=1;
      
      if( a == 15) {
         printf("Escaping for loops...\n");
         break;
      }
   }
 
   return 0;
}