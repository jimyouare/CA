#include <stdio.h>

int main(){
    
    int sum = 0,i;
    
    for(i=0; i <= 10; i++){
        sum+=i;
    }
    
    printf("Sum is %d \n\n", sum);
    
    sum = 0;
    i=0;
    
    while(i <= 10){
        
        sum+=i;
        
        i++;
        
    }
    
    printf("Sum of numbers between 0 and 10 is %d \n\n", sum);
    
    return 0;
    
}