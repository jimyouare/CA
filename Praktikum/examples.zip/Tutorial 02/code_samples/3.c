#include <stdio.h>

#define NAME "University of Bern"
#define AGE 185

int main(){
    
   printf("%s is over %d years old.\n", NAME, AGE);
   return 0;
}