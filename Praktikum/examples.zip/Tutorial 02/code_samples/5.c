#include <stdio.h>

int main(){

    int sum = 0,i;
    
    for(i=0; i <= 10; i++){
        
        if(i%2 == 0){
            
            sum+=i;
        
        }
        
    }
    
    printf("Sum of even numbers between 0 and 10 is %d \n\n", sum);
    
    return 0;
    
}