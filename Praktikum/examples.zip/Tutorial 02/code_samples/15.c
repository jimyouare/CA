#include <stdio.h>
#include <string.h>

typedef struct {
   unsigned int age : 3;
} Age;

int main( ) {

    Age age;
    
    age.age = 1;
    printf( "Sizeof( age ) : %lu\n", sizeof(age) );
    printf( "Age.age : %u\n", age.age );

    age.age = 7;
    printf( "Age.age : %u\n", age.age );

    age.age = 8;
    printf( "Age.age : %u\n", age.age );

    return 0;
}