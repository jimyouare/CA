#include <stdio.h>

int main (){
    
    short int a = 7;
    printf("%hd \n", a);
    printf("Size of \"short int\" is %lu bytes \n\n",sizeof(a));
        
    unsigned short int b = 7;
    printf("%hu \n", b);
    printf("Size of \"unsigned short int\" is %lu bytes \n\n",sizeof(b));
        
    unsigned int c = 7;
    printf("%u \n", c);
    printf("Size of \"unsigned int\" is %lu bytes \n\n",sizeof(c));
    
    int d = 7;
    printf("%d \n", d);
    printf("Size of \"int\" is %lu bytes \n\n",sizeof(d));
    
    long int e= 7;
    printf("%ld \n", e);
    printf("Size of \"long int\" is %lu bytes \n\n",sizeof(e));
        
    unsigned long int f = 7;
    printf("%lu \n", f);
    printf("Size of \"unsigned long int\" is %lu bytes \n\n",sizeof(f));
        
    long long int g = 7;
    printf("%lld \n", g);
    printf("Size of \"long long int\" is %lu bytes \n\n",sizeof(g));
        
    unsigned long long int h = 7;
    printf("%llu \n", h);
    printf("Size of \"unsigned long long int\" is %lu bytes \n\n",sizeof(h));
        
    float i = 7;
    printf("%f \n", i);
    printf("Size of \"float\" is %lu bytes \n\n",sizeof(i));
        
    double j = 7;
    printf("%lf \n", j);
    printf("Size of \"double\" is %lu bytes \n\n",sizeof(j));
    
    long double k = 7;
    printf("%Lf \n", k);
    printf("Size of \"long double\" is %lu bytes \n\n",sizeof(k));
    
    return 0;

}