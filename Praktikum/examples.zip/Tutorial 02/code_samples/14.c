#include <stdio.h>
#include <string.h>

struct Age {
   unsigned int age : 3;
};

int main( ) {

    struct Age age;
    
    age.age = 1;
    printf( "Sizeof( age ) : %lu\n", sizeof(age) );
    printf( "Age.age : %u\n", age.age );

    age.age = 7;
    printf( "Age.age : %u\n", age.age );

    age.age = 8;
    printf( "Age.age : %u\n", age.age );

    return 0;
}