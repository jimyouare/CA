#include <stdio.h>
 
int main () {

   int array[5][5];
   
   printf("Matrix in C is EASY!!!... \n\n");
   
   for(int i=0; i < 5; i++){
       
       for(int j=0; j < 5; j++){
           
           array[i][j] = i*j;
           
           printf("%d ",array[i][j]);
           
       }
       
       printf("\n");
       
   }
 
   return 0;
}