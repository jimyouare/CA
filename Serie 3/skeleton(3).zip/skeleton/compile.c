/* TODO: Task (b) Please fill in the following lines, then remove this line.
 *
 * author(s):   FIRSTNAME LASTNAME 
 *              (FIRSTNAME2 LASTNAME2)
 * modified:    2010-01-07
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include "memory.h"
#include "mips.h"
#include "compiler.h"
 
int main ( int argc, char** argv ) {
    /* TODO: Task (c) implement main */
    return EXIT_SUCCESS;
}

